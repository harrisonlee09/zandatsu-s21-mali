package com.dfdx047.zandatsu.data

import android.content.Context
import android.content.SharedPreferences

enum class ThemeMode(val key: String) { GAME("game"), MATERIAL_YOU("material_you") }
enum class DarkMode(val key: String) { SYSTEM("system"), LIGHT("light"), DARK("dark") }
enum class AppLanguage(val tag: String) { SYSTEM(""), PORTUGUESE("pt"), ENGLISH("en"), SPANISH("es") }

/**
 * Orientacao do jogo: paisagem, vertical (o jogo em cima, controles por baixo) ou pelo sensor
 * (roda com o aparelho). Os valores sao lidos tambem pelo GameActivity (Java).
 */
enum class GameOrientation(val key: String) { LANDSCAPE("landscape"), PORTRAIT("portrait"), AUTO("auto") }

/**
 * Aspeto dos controles por toque. GAME = o estilo MGR (vidro grafite com icones
 * do jogo; o nome fica pelas preferencias gravadas); XBOX / PLAYSTATION / NINTENDO = letras ou
 * simbolos do comando.
 */
/**
 * Visual dos controles na tela. GAME ("Classico"): vidro grafite com icones; SCIFI (27/10): hexagonos de linhas finas,
 * cantos cortados, vermelho e branco sobre preto translucido (desenho original, nada tirado do jogo). Os outros: as
 * letras/simbolos do comando.
 */
enum class ControlStyle(val key: String) {
    GAME("game"), SCIFI("scifi"), XBOX("xbox"), PLAYSTATION("playstation"), NINTENDO("nintendo");

    /** Botoes com o icone da acao (e o selo do comando no canto), nao a letra. */
    val iconic: Boolean get() = this == GAME || this == SCIFI
}

/** Direcional na tela: analogico (padrao, o MGR e 3D) ou D-pad de 8 direcoes. */
enum class Directional(val key: String) { DPAD("dpad"), STICK("stick") }

/**
 * Controles na tela. AUTO: aparecem ao tocar na tela e somem quando se usa um
 * comando fisico; ON: sempre; OFF: nunca (a engrenagem e o pause continuam).
 */
enum class TouchMode(val key: String) { AUTO("auto"), ON("on"), OFF("off") }

/** Indicacao do botao do comando no canto de cada botao (estilo Zandatsu). */
enum class ButtonBadge(val key: String) { XBOX("xbox"), PLAYSTATION("playstation"), NINTENDO("nintendo"), NONE("none") }

inline fun <reified T : Enum<T>> enumByKey(value: String?, default: T, key: (T) -> String): T =
    enumValues<T>().firstOrNull { key(it) == value } ?: default

/**
 * Preferencias do launcher (nao do jogo: essas vivem no mgr.toml).
 * O GameActivity le as mesmas chaves (PREFS_NAME, KEY_*).
 */
class LauncherPrefs(context: Context) {
    private val appContext = context.applicationContext

    // O jogo corre noutro processo (":game"). MODE_MULTI_PROCESS (obsoleto mas ainda
    // funcional) faz o Android reler o ficheiro quando o outro processo o mudou: sem
    // isto, o launcher gravaria por cima do que se mudou no menu dentro do jogo.
    @Suppress("DEPRECATION")
    private val prefs: SharedPreferences
        get() = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_MULTI_PROCESS)

    var themeMode: ThemeMode
        get() = enumByKey(prefs.getString(KEY_THEME, null), ThemeMode.GAME) { it.key }
        set(v) = prefs.edit().putString(KEY_THEME, v.key).apply()

    var darkMode: DarkMode
        get() = enumByKey(prefs.getString(KEY_DARK, null), DarkMode.DARK) { it.key }
        set(v) = prefs.edit().putString(KEY_DARK, v.key).apply()

    var gameOrientation: GameOrientation
        get() = enumByKey(prefs.getString(KEY_ORIENTATION, null), GameOrientation.LANDSCAPE) { it.key }
        set(v) = prefs.edit().putString(KEY_ORIENTATION, v.key).apply()

    /**
     * Correcoes para o Turnip nos Adreno 6xx: bits independentes (ver TURNIP_* no
     * GameActivity, que le esta chave antes de o driver carregar).
     */
    var turnipCompatFlags: Int
        get() = prefs.getInt(KEY_TURNIP_COMPAT_FLAGS, 0)
        set(v) = prefs.edit().putInt(KEY_TURNIP_COMPAT_FLAGS, v).apply()

    /** O jogador ja escolheu um perfil no ecra do primeiro arranque (ProfilePicker). */
    var profileChosen: Boolean
        get() = prefs.getBoolean("profile_chosen", false)
        set(v) = prefs.edit().putBoolean("profile_chosen", v).apply()

    /** Cheats: o jogo corre acelerado durante as logos (swordman_boot_fast_forward, patch 0168). */
    var skipLogos: Boolean
        get() = prefs.getBoolean("cheat_skip_logos", false)
        set(v) = prefs.edit().putBoolean("cheat_skip_logos", v).apply()

    /** Bisect do Turnip (TurnipSupport.BISECT): um passo por arranque do jogo. */
    var turnipBisect: Boolean
        get() = prefs.getBoolean("turnip_bisect", false)
        set(v) = prefs.edit().putBoolean("turnip_bisect", v).apply()
    var turnipBisectStep: Int
        get() = prefs.getInt("turnip_bisect_step", 0)
        set(v) = prefs.edit().putInt("turnip_bisect_step", v).apply()

    /** Driver alternativo que falhou [DriverBootFails.LIMIT]+ arranques seguidos; "" = nenhum. */
    val driverBootFailed: String
        get() = if (DriverBootFails.read() >= DriverBootFails.LIMIT) {
            com.dfdx047.zandatsu.drivers.DriverRepository.activeDir()?.let { java.io.File(it).name } ?: ""
        } else {
            ""
        }

    fun clearDriverBootState() {
        prefs.edit().remove("driver_boot_failed").remove("driver_boot_pending").apply()
        DriverBootFails.reset()
    }

    var controlStyle: ControlStyle
        get() = enumByKey(prefs.getString(KEY_CONTROL_STYLE, null), ControlStyle.GAME) { it.key }
        set(v) = prefs.edit().putString(KEY_CONTROL_STYLE, v.key).apply()

    var directional: Directional
        get() = enumByKey(prefs.getString(KEY_DIRECTIONAL, null), Directional.STICK) { it.key }
        set(v) = prefs.edit().putString(KEY_DIRECTIONAL, v.key).apply()

    var buttonBadge: ButtonBadge
        get() = enumByKey(prefs.getString(KEY_BADGE, null), ButtonBadge.XBOX) { it.key }
        set(v) = prefs.edit().putString(KEY_BADGE, v.key).apply()

    /** Pausar o jogo enquanto o menu dos controles ou o menu rapido do port estao abertos. */
    var pauseOnMenus: Boolean
        get() = prefs.getBoolean(KEY_PAUSE_MENUS, true)
        set(v) = prefs.edit().putBoolean(KEY_PAUSE_MENUS, v).apply()

    var touchMode: TouchMode
        get() {
            val v = prefs.getString(KEY_TOUCH_MODE, null)
            if (v == null && !prefs.getBoolean(KEY_TOUCH_ENABLED, true)) return TouchMode.OFF
            return enumByKey(v, TouchMode.AUTO) { it.key }
        }
        set(v) = prefs.edit().putString(KEY_TOUCH_MODE, v.key).apply()

    var touchEnabled: Boolean
        get() = prefs.getBoolean(KEY_TOUCH_ENABLED, true)
        set(v) = prefs.edit().putBoolean(KEY_TOUCH_ENABLED, v).apply()

    var touchHideWithPad: Boolean
        get() = prefs.getBoolean(KEY_TOUCH_HIDE_WITH_PAD, true)
        set(v) = prefs.edit().putBoolean(KEY_TOUCH_HIDE_WITH_PAD, v).apply()

    var touchHaptics: Boolean
        get() = prefs.getBoolean(KEY_TOUCH_HAPTICS, true)
        set(v) = prefs.edit().putBoolean(KEY_TOUCH_HAPTICS, v).apply()

    /** Opacidade global dos controles (0.1-1), multiplica a de cada botao. */
    /** Troca automatica menu/luta dos controles na tela. */
    var touchAutoSwitch: Boolean
        get() = prefs.getBoolean("touch_auto_switch", true)
        set(value) = prefs.edit().putBoolean("touch_auto_switch", value).apply()

    /** LT alterna: um toque entra no Blade Mode e outro sai (em vez de segurar). */
    var bladeToggle: Boolean
        get() = prefs.getBoolean("touch_blade_toggle", true)
        set(value) = prefs.edit().putBoolean("touch_blade_toggle", value).apply()

    /** Tamanho de todos os botoes (multiplica o de cada um). */
    var touchScale: Float
        get() = prefs.getFloat("touch_scale", 1f)
        set(value) = prefs.edit().putFloat("touch_scale", value).apply()

    var touchOpacity: Float
        get() = prefs.getFloat(KEY_TOUCH_OPACITY, 0.75f)
        set(v) = prefs.edit().putFloat(KEY_TOUCH_OPACITY, v).apply()

    var turnipNoticeShown: Boolean
        get() = prefs.getBoolean(KEY_TURNIP_NOTICE, false)
        set(v) = prefs.edit().putBoolean(KEY_TURNIP_NOTICE, v).apply()

    /** Aviso de primeiro arranque sobre GPUs/drivers (substitui o aviso so do Turnip). */
    var gpuNoticeShown: Boolean
        get() = prefs.getBoolean(KEY_GPU_NOTICE, false)
        set(v) = prefs.edit().putBoolean(KEY_GPU_NOTICE, v).apply()

    /** A migracao unica do perfil Baixo para a v1.2 ja correu. */
    var lowAudioMigrated: Boolean
        get() = prefs.getBoolean("low_audio_migrated", false)
        set(v) = prefs.edit().putBoolean("low_audio_migrated", v).apply()

    /** Versao (versionName) cujas novidades o jogador ja viu; null = nenhuma. */
    var whatsNewSeen: String?
        get() = prefs.getString("whats_new_seen", null)
        set(v) = prefs.edit().putString("whats_new_seen", v).apply()

    /** Ultima saida anormal do jogo ja mostrada (ApplicationExitInfo.timestamp). */
    var lastCrashShown: Long
        get() = prefs.getLong(KEY_LAST_CRASH_SHOWN, 0L)
        set(v) = prefs.edit().putLong(KEY_LAST_CRASH_SHOWN, v).apply()

    var checkUpdatesOnStart: Boolean
        get() = prefs.getBoolean(KEY_CHECK_UPDATES, true)
        set(v) = prefs.edit().putBoolean(KEY_CHECK_UPDATES, v).apply()

    /** Versao que o usuario mandou ignorar no pop-up de atualizacao. */
    var skippedUpdate: String?
        get() = prefs.getString(KEY_SKIPPED_UPDATE, null)
        set(v) = prefs.edit().putString(KEY_SKIPPED_UPDATE, v).apply()

    companion object {
        const val PREFS_NAME = "swordman"
        const val KEY_THEME = "theme"
        const val KEY_DARK = "dark_mode"
        const val KEY_ORIENTATION = "game_orientation"
        const val KEY_TURNIP_COMPAT_FLAGS = "turnip_compat_flags"
        const val KEY_CONTROL_STYLE = "control_style"
        const val KEY_DIRECTIONAL = "touch_directional"
        const val KEY_BADGE = "touch_badge"
        const val KEY_PAUSE_MENUS = "pause_on_menus"
        const val KEY_TOUCH_MODE = "touch_mode"
        const val KEY_TOUCH_ENABLED = "touch_enabled"
        const val KEY_TOUCH_HIDE_WITH_PAD = "touch_hide_with_pad"
        const val KEY_TOUCH_HAPTICS = "touch_haptics"
        const val KEY_TOUCH_OPACITY = "touch_opacity"
        const val KEY_TURNIP_NOTICE = "turnip_notice_shown"
        const val KEY_GPU_NOTICE = "gpu_notice_shown"
        const val KEY_LAST_CRASH_SHOWN = "last_crash_shown"
        const val KEY_CHECK_UPDATES = "check_updates"
        const val KEY_SKIPPED_UPDATE = "skipped_update"
    }
}
