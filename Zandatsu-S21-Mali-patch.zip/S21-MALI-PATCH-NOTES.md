# Zandatsu S21 / Mali-G78 compatibility patch

This is a source patch overlay for the uploaded `Zandatsu-main` snapshot.

## Intended changes
- Adds a point-sprite geometry shader variant that reads SharedConstants from the UBO instead of a 64-bit device address.
- Avoids creating the Int64 point-sprite SPIR-V module when `shaderInt64` is unavailable.
- Selects CPU BC texture decoding when the device lacks both `shaderInt64` and native BC texture compression, avoiding the Int64 BC compute shader.
- Generates the additional `point_sprite_ubo_gs` SPIR-V header during the shader build.
- Leaves Xenia available as the fallback renderer; it does not force Renut.

## Files changed
- `src/renut_glue.cpp`
- `tools/renut-shaders.sh`
- `patches/renut/0030-point-sprite-ubo-no-int64.patch`
- `patches/renut/0031-no-int64-module-without-shaderint64.patch`

## Important limitations
This is **not a built APK**. The uploaded source archive does not include the `third_party/mgr-nx-deko` Git submodule contents or the generated game/host shader cache under `out/renut`. The two new Renut patches therefore still need to be applied to the exact submodule revision pinned by Zandatsu, and the complete Android build must be run with the project's required SDK/NDK and private game shader inputs.

The Dragon Burst patch series also contains game-specific changes. Only the two targeted renderer changes above were selected; unrelated Dragon Burst gameplay/render patches were not copied.

## Validation still required on a Galaxy S21 (Exynos 2100 / Mali-G78)
1. Build the ARM64 debug APK and confirm the Renut device check no longer rejects `shaderInt64`.
2. Confirm the startup log selects `point_sprite_ubo_gs`.
3. Confirm BC decode is set to `cpu` when `textureCompressionBC` is false.
4. Test a scene with point sprites and BC textures for correct output.
5. Compare Renut stability/performance against Xenia. CPU BC decoding can cost performance; this patch is a compatibility path, not a guarantee of higher FPS.

Do not enable unsupported Vulkan features by force. The patch changes the shader path rather than falsely advertising `shaderInt64`.
